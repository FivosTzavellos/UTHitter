const UTHitter = artifacts.require("UTHitter");

module.exports = function(deployer) {
  deployer.deploy(UTHitter);
};
